function Game(appName, packageName,color,isClickable,runTime) {
    this.appName = appName;
    this.packageName = packageName;
    this.color = color;
    this.isClickable = isClickable;
    this.runTime = runTime;
}
module.exports=Game;